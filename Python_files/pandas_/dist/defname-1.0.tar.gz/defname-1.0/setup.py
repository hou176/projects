
from setuptools import setup
setup(name='defname',
      version='1.0',
      py_modules=['defname'],
      )